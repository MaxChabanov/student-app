/**
 * Entry point for all public APIs of the package.
 */
export * from './src/ng2-completer';
