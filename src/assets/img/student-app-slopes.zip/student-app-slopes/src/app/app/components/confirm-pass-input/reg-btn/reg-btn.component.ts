import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-btn',
  templateUrl: './reg-btn.component.html',
  styleUrls: ['./reg-btn.component.scss']
})
export class RegBtnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
