import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pass-input',
  templateUrl: './pass-input.component.html',
  styleUrls: ['./pass-input.component.scss']
})
export class PassInputComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
