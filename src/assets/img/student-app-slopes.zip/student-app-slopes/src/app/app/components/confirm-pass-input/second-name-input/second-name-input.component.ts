import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second-name-input',
  templateUrl: './second-name-input.component.html',
  styleUrls: ['./second-name-input.component.scss']
})
export class SecondNameInputComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
