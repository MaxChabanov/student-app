import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-pass-input',
  templateUrl: './confirm-pass-input.component.html',
  styleUrls: ['./confirm-pass-input.component.scss']
})
export class ConfirmPassInputComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
