import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first-name-input',
  templateUrl: './first-name-input.component.html',
  styleUrls: ['./first-name-input.component.scss']
})
export class FirstNameInputComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
